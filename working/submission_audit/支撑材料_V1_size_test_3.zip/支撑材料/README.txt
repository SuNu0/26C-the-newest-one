2026年全国大学生数学建模竞赛 C 题支撑材料

目录：code 为求解与验证程序；附件为运行输入及结果模板；results 为主要结果；figures 为论文图表。

建议使用 Python 3.11 或更高版本。
在本文件所在目录执行：
python -m pip install -r requirements-problem1.txt
python -m pip install -r requirements-q234.txt
python code/problem1_solve.py
python code/problem1_validate.py
python code/q234_solve.py
python code/q234_validate.py
python code/test_time_alignment.py

赛题原始附件一至附件四随包保留，用于保证程序可独立运行。完整逐时段结果体积较大，可通过 q234_solve.py 重新生成。
